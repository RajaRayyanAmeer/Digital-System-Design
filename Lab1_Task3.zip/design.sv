module mux2(
  input A,B,S0,
  output F1);
  wire W1,W2,W3,W4;
  not n1(W1,S0);
  and a1(W2,W1,A);
  and a2(W3,A,B);
  and a3(W4,S0,B);
  or o1(F,W2,W3,W4);
endmodule

module mux4(
  input A,B,C,D,S0,S1,
  output F3
);
  wire F1,F2;
  mux2 m1(A,B,S0,F1);
  mux2 m2(C,D,S0,F2);
  mux2 m3(F1,F2,S1,F3);
endmodule