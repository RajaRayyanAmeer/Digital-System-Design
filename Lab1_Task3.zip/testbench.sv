module tb_mux4;
  reg A,B,C,D,S0,S1;
  wire F3;
  mux4 m1(.A(A),.B(B),.C(C),.D(D),.S0(S0),.S1(S1),.F3(F3));
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1);
      A=0;B=0;C=0;D=0;S0=0;S1=0;
      #10A=1;B=0;C=0;D=0;S0=0;S1=0;
      #10A=0;B=0;C=0;D=0;S0=0;S1=1;
      #10A=0;B=1;C=0;D=0;S0=0;S1=1;
      #10A=0;B=0;C=0;D=0;S0=1;S1=0;
      #10A=0;B=0;C=1;D=0;S0=1;S1=0;
      #10A=0;B=0;C=0;D=0;S0=1;S1=1;
      #10A=0;B=0;C=0;D=1;S0=1;S1=1;
      $finish;
    end
endmodule