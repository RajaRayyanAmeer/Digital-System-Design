module N_bit_register_tb;
  parameter N = 8;
  reg [N - 1 : 0] D;
  reg Clk, Rst;
  wire [N - 1 : 0] Q;
  N_bit_register n1(D, Clk, Rst, Q);
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1, N_bit_register_tb);
    end
  initial
    begin
      Clk = 0;
      forever #1 Clk = ~Clk;
    end
  initial
    begin
      Rst = 1; D = 8'b00000000;
      #2 Rst = 0;
      #2 D = 8'b00000000;
      #2 D = 8'b00001111;
      #2 D = 8'b00001101;
      #2 D = 8'b01000111;
      #2 D = 8'b01001111;
      #2 Rst = 1;
      #2 Rst = 0;
      #2 D = 8'b11001111;
      #2 D = 8'b00111111;
      #2
      $finish();
    end
endmodule