module d_flipflop(
  input D, Clk, Rst,
  output reg Q);
  always @ (posedge Clk or posedge Rst)
    begin
      if (Rst)
        Q <= 1'b0;
      else
        Q <= D;
    end
endmodule

module N_bit_register 
  #(parameter N = 8)
  (
  input [N - 1 : 0]D,
  input Clk, Rst,
  output [N - 1 : 0]Q
  ); 
  genvar i;
  generate
    for (i = 0; i < N; i = i + 1)
      begin: N_Reg
        d_flipflop d1(.D(D[i]), .Clk(Clk), .Rst(Rst), .Q(Q[i]));
      end
  endgenerate
endmodule