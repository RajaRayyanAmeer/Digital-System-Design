module tb_decoder2x4;
  reg A0,A1,E;
  wire D0,D1,D2,D3;
  decoder2x4 d1(A0,A1,E,D0,D1,D2,D3);
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(0);
      A0=0;A1=0;E=1;
      #5A0=0;A1=1;E=1;
      #5A0=1;A1=0;E=1;
      #5A0=1;A1=1;E=1;
      #5;
      $finish();
    end
endmodule