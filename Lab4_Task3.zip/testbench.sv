module d_flipflop_tb;
  reg D, Clk;
  wire Q;
  d_flipflop d3(D, Clk, Q);
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1, d_flipflop_tb);
    end
  initial
    begin
      Clk = 0;
      forever
        #1 Clk = ~Clk;
    end
  initial
    begin
      D = 0;
      #2 D = 1;
      #2 D = 0;
      #2 D = 1;
      #2
      $finish();
    end
endmodule