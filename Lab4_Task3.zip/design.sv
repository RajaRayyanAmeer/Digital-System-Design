module d_latch(
  input D, Clk,
  output reg Q);
  
  always @ (D or Clk)
    begin
      if (Clk)
        begin
          Q <= D;
        end
    end
endmodule

module d_flipflop(
  input D, Clk,
  output wire Q);
  wire Qm, nClk;
  assign nClk = ~Clk;
  d_latch d1(.D(D), .Clk(Clk), .Q(Qm));   // Master D Latch
  d_latch d2(.D(Qm), .Clk(nClk), .Q(Q)); // Slave D Latch
endmodule