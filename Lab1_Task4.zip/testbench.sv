module tb_full_adder;
  reg A,B,Cin;
  wire Sum1,Cout;
  full_adder f1(.A(A),.B(B),.Cin(Cin),.Sum1(Sum1),.Cout(Cout));
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1);
      A=0;B=0;Cin=0;
      #10A=0;B=0;Cin=1;
      #10A=0;B=1;Cin=0;
      #10A=0;B=1;Cin=1;
      #10A=1;B=0;Cin=0;
      #10A=1;B=0;Cin=1;
      #10A=1;B=1;Cin=0;
      #10A=1;B=1;Cin=1;
      $finish;
    end
endmodule