module half_adder(
  input A,B,
  output SUM,CARRY
);
  xor x1(SUM,A,B);
  and a1(CARRY,A,B);
endmodule

module full_adder(
  input A,B,Cin,
  output Sum1,Cout);
  wire SUM,CARRY,Carry1;
  half_adder h1(A,B,SUM,CARRY);
  half_adder h2(SUM,Cin,Sum1,Carry1);
  or o1(Cout,Carry,Carry1);
endmodule