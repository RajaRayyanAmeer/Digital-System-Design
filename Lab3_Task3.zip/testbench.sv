module tb_subtractor4;
  reg A,B,Bin;
  wire Diff,Bor;
  subtractor4 S0 (A,B,Bin,Diff,Bor);
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1,tb_subtractor4);
      A=0;B=0;Bin=0;
      #1A=0;B=0;Bin=1;
      #1A=0;B=1;Bin=0;
      #1A=0;B=1;Bin=1;
      #1A=1;B=0;Bin=0;
      #1A=1;B=0;Bin=1;
      #1A=1;B=1;Bin=0;
      #1A=1;B=1;Bin=1;
      $finish();
    end
endmodule