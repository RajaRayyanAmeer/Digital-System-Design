module subtractor(
  input A,B,Bin,
  output Diff,Bor);
  assign Diff = A ^ B ^ Bin;
  assign Bor = (B & Bin) | (!A & (B | Bin));
endmodule

module subtractor4(
  input [3:0]A,B,
  input Bin,
  output [3:0]Diff,
  output Bor);
  wire W1,W2,W3;
  subtractor s0(A[0],B[0],Bin,Diff[0],W1);
  subtractor s1(A[1],B[1],W1,Diff[1],W2);
  subtractor s2(A[2],B[2],W2,Diff[2],W3);
  subtractor s3(A[3],B[3],W3,Diff[3],Bor);
endmodule