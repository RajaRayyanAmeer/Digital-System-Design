module decoder2_4(
  input A,B,E,
  output O1,O2,O3,O4);
  wire W1,W2;
  not n1(W1,A);
  not n2(W2,B);
  and a1(O1,W1,W2,E);
  and a2(O2,W1,B,E);
  and a3(O3,A,W2,E);
  and a4(O4,A,B,E);
endmodule

module decoder3_8(
  input A,B,C,E,
  output O1,O2,O3,O4,O5,O6,O7,O8);
  wire W3;
  not n5(E,C);
  decoder2_4 dc1(A,B,E,O1,O2,O3,O4);
  decoder2_4 dc2(A,B,C,O5,O6,O7,O8);
endmodule