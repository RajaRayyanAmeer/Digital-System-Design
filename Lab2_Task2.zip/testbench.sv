module tb_decoder3_8;
  reg A,B,C,E;
  wire O1,O2,O3,O4,O5,O6,O7,O8;
  decoder3_8 dc(A,B,C,E,O1,O2,O3,O4,O5,O6,O7,O8);
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1,tb_decoder3_8);
      A=0;B=0;C=0;
      #3A=0;B=0;C=1;
      #3A=0;B=1;C=0;
      #3A=0;B=1;C=1;
      #3A=1;B=0;C=0;
      #3A=1;B=0;C=1;
      #3A=1;B=1;C=0;
      #3A=1;B=1;C=1;
      $finish();
    end
endmodule