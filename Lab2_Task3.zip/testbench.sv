module tb_bcd_excess3;
  reg A,B,C,D;
  wire W,X,Y,Z;
  bcd_excess3 be3_m2(.A(A),.B(B),.C(C),.D(D),.W(W),.X(X),.Y(Y),.Z(Z));
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1,tb_bcd_excess3);
      A=0;B=0;C=0;D=0;
      #3A=0;B=0;C=0;D=1;
      #3A=0;B=0;C=1;D=0;
      #3A=0;B=0;C=1;D=1;
      #3A=0;B=1;C=0;D=0;
      #3A=0;B=1;C=0;D=1;
      #3A=0;B=1;C=1;D=0;
      #3A=0;B=1;C=1;D=1;
      #3A=1;B=0;C=0;D=0;
      #3A=1;B=0;C=0;D=1;
      $finish();
    end
endmodule