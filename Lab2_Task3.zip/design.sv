module mux2x1(
  input S,I0,I1,
  output V);
  wire W0,W00,W000;
  not n1(W0,S);
  and a1(W00,I1,S);
  and a2(W000,W0,I0);
  or o1(V,W00,W000);  
endmodule

module bcd_excess3(
  input A,B,C,D,
  output W,X,Y,Z);
  wire W1,W2,W3,W4;
  mux2x1 m1(.S(D),.I0(1),.I1(0),.V(Z));
  mux2x1 m2(.S(D),.I0(1),.I1(0),.V(W1));
  mux2x1 m3(.S(C),.I0(W1),.I1(D),.V(Y));
  mux2x1 m4(.S(C),.I0(D),.I1(1),.V(W2));
  mux2x1 m5(.S(W2),.I0(1),.I1(0),.V(W3));
  mux2x1 m6(.S(B),.I0(W2),.I1(W3),.V(X));
  mux2x1 m7(.S(B),.I0(0),.I1(W2),.V(W4));
  mux2x1 m8(.S(A),.I0(W4),.I1(1),.V(W));
endmodule