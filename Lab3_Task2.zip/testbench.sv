module tb_mux8x1;
  reg S2,S1,S0,I0,I1,I2,I3,I4,I5,I6,I7;
  wire Y;
  mux8x1 m1(S2,S1,S0,I0,I1,I2,I3,I4,I5,I6,I7,Y);
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1);
      I0=0; I1=1; I2=0; I3=1; I4=0; I5=1; I6=0; I7=1;
      S2=0;S1=0;S0=0;
      #2S2=0;S1=0;S0=1;
      #2S2=0;S1=1;S0=0;
      #2S2=0;S1=1;S0=1;
      #2S2=1;S1=0;S0=0;
      #2S2=1;S1=0;S0=1;
      #2S2=1;S1=1;S0=0;
      #2S2=1;S1=1;S0=1;
      $finish();
    end
endmodule