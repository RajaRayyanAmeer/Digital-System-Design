module tb_FA16;
  reg [15:0]A,B;
  reg Cin;
  wire [15:0]S;
  wire Cout;
  FA16 fa16(.A(A),.B(B),.Cin(Cin),.S(S),.Cout(Cout));
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1,tb_FA16);
      A=0;B=0;Cin=0;
      #3A=0;B=0;Cin=1;
      #3A=0;B=1;Cin=0;
      #3A=0;B=1;Cin=1;
      #3A=1;B=0;Cin=0;
      #3A=1;B=0;Cin=1;
      #3A=1;B=1;Cin=0;
      #3A=1;B=1;Cin=1;
      $finish;
    end
endmodule