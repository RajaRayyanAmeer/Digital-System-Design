module FA1(
  input A,B,Cin,
  output S,Cout);
  wire W1,W2,W3;
  xor x1(S,A,B,Cin);
  and a1(W1,A,B);
  and a2(W2,Cin,B);
  and a3(W3,A,Cin);
  or o1(Cout,W1,W2,W3);
endmodule

module FA4(
  input [3:0]A,B,
  input Cin,
  output [3:0]S,
  output Cout);
  wire W4,W5,W6;
  FA1 f1(A[0],B[0],Cin,S[0],W4);
  FA1 f2(A[1],B[1],W4,S[1],W5);
  FA1 f3(A[2],B[2],W5,S[2],W6);
  FA1 f4(A[3],B[3],W6,S[3],Cout);
endmodule

module FA16(
  input [15:0]A,B,
  input Cin,
  output [15:0]S,
  output Cout);
  wire W7,W8,W9;
  FA4 f5(A[3:0],B[3:0],Cin,S[3:0],W7);
  FA4 f6(A[7:4],B[7:4],W7,S[7:4],W8);
  FA4 f7(A[11:8],B[11:8],W8,S[11:8],W9);
  FA4 f8(A[15:12],B[15:12],W9,S[15:12],Cout);
endmodule