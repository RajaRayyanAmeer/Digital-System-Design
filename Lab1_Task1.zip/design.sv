module half_adder(
  input A,B,
  output SUM,CARRY
);
  xor x1(SUM,A,B);
  and a1(CARRY,A,B);
endmodule