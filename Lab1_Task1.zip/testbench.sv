module tb_half_adder;
  reg A,B;
  wire SUM,CARRY;
  half_adder h1(.A(A),.B(B),.SUM(SUM),.CARRY(CARRY));
  initial
    begin
        $dumpfile("dump.vcd");
      $dumpvars(1,tb_half_adder);
      A=0;B=0;
      #10A=0;B=1;
      #10A=1;B=0;
      #10A=1;B=1;
      $finish;
    end
endmodule