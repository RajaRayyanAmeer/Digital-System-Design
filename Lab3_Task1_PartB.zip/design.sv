module decoder2x4(
  input A0,A1,E,
  output D0,D1,D2,D3);
  wire W1,W2;
  assign #5 W1 = !A0;
  assign #5 W2 = !A1;
  assign #6 D0 = E && (W1) && (W2);
  assign D1 = E && (W1) && (A1);
  assign D2 = E && (A0) && (W2);
  assign D3 = E && (A0) && (A1);
endmodule