module full_8adder(
  input A0,A1,A2,A3,A4,A5,A6,A7,B0,B1,B2,B3,B4,B5,B6,B7,Cin,
  output S0,S1,S2,S3,S4,S5,S6,S7,Cout);
  wire W1,W2,W3,W4,W5,W6,W7,W8,W9,W10,W11,W12,W13,W14,W15,W16,W17,W18,W19,W20,W21,W22,W23,W24,C0,C1,C2,C3,C4,C5,C6;

  and a1(W1,Cin,B0);
  and a2(W2,Cin,A0);
  and a3(W3,A0,B0);
  or o1(C0,W1,W2,W3);
  
  and a4(W4,C0,B1);
  and a5(W5,C0,A1);
  and a6(W6,A1,B1);
  or o2(C1,W4,W5,W6);
  
  and a7(W7,C1,B2);
  and a8(W8,C1,A2);
  and a9(W9,A2,B2);
  or o3(C2,W7,W8,W9);
  
  and a10(W10,C2,B3);
  and a11(W11,C2,A3);
  and a12(W12,A3,B3);
  or o4(C3,W10,W11,W12);
  
  and a13(W13,C3,B4);
  and a14(W14,C3,A4);
  and a15(W15,A4,B4);
  or o5(C4,W13,W14,W15);
  
  and a16(W16,C4,B5);
  and a17(W17,C4,A5);
  and a18(W18,A5,B5);
  or o6(C5,W16,W17,W18);
  
  and a19(W19,C5,B6);
  and a20(W20,C5,A6);
  and a21(W21,A6,B6);
  or o7(C6,W19,W20,W21);
  
  and a22(W22,C6,B7);
  and a23(W23,C6,A7);
  and a24(W24,A7,B7);
  or o8(Cout,W22,W23,W24);
  
  xor x1(S0,A0,B0,Cin);
  xor x2(S1,A1,B1,C0);
  xor x3(S2,A2,B2,C1);
  xor x4(S3,A3,B3,C2);
  xor x5(S4,A4,B4,C3);
  xor x6(S5,A5,B5,C4);
  xor x7(S6,A6,B6,C5);
  xor x8(S7,A7,B7,C6);
  
endmodule