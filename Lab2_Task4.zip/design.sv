module compares(
  input A0,A1,B0,B1,
  output E,G,L);
  wire W1,W2,W3,W4,W5,W6,W7,W8,W9,W10,W11,W12;
  xnor x1(W1,A0,B0);
  xnor x2(W2,A1,B1);
  and a1(E,W1,W2);
  not n1(W3,A0);
  not n2(W4,A1);
  not n3(W5,B0);
  not n4(W6,B1);
  and a2(W8,A1,W6);
  and a3(W7,A0,W5);
  and a4(W9,W2,W7);
  or o1(G,W9,W7);
  and a5(W10,W4,B1);
  and a6(W11,W3,B0);
  and a7(W12,W2,W11);
  or(L,W10,W12);
endmodule