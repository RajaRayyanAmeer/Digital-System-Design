module tb_compares;
  reg A0,A1,B0,B1;
  wire E,G,L;
  compares c1(A0,A1,B0,B1,E,G,L);
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(0);
      A0=0;A1=0;B0=0;B1=0;
      #2A0=0;A1=0;B0=0;B1=1;
      #2A0=0;A1=0;B0=1;B1=0;
      #2A0=0;A1=0;B0=1;B1=1;
      #2A0=0;A1=1;B0=0;B1=0;
      #2A0=0;A1=1;B0=0;B1=1;
      #2A0=0;A1=1;B0=1;B1=0;
      #2A0=0;A1=1;B0=1;B1=1;
      #2A0=1;A1=0;B0=0;B1=0;
      #2A0=1;A1=0;B0=0;B1=1;
      #2A0=1;A1=0;B0=1;B1=0;
      #2A0=1;A1=0;B0=1;B1=1;
      #2A0=1;A1=1;B0=0;B1=0;
      #2A0=1;A1=1;B0=0;B1=1;
      #2A0=1;A1=1;B0=1;B1=0;
      #2A0=1;A1=1;B0=1;B1=1;
      $finish();
    end
endmodule