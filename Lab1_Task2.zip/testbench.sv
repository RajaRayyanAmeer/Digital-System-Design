module tb_mux2;
  reg A,B,S;
  wire F;
  mux2 m1(.A(A),.B(B),.S(S),.F(F));
  initial
    begin
      $dumpfile("dump.vcd");
      $dumpvars(1,tb_mux2);
      A=0;B=0;S=0;
      #10A=0;B=1;S=0;
      #10A=1;B=0;S=0;
      #10A=1;B=1;S=0;
      #10A=0;B=0;S=1;
      #10A=0;B=1;S=1;
      #10A=1;B=0;S=1;
      #10A=1;B=1;S=1;
      $finish;
    end
endmodule  