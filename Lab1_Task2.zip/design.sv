module mux2(
  input A,B,S,
  output F);
  wire W1,W2,W3,W4;
  not n1(W1,S);
  and a1(W2,W1,A);
  and a2(W3,A,B);
  and a3(W4,S,B);
  or o1(F,W2,W3,W4);
endmodule