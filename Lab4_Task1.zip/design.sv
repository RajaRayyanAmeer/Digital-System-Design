module rs_latch(
  input R,S,
  output Q,Qbar);
  assign Q = ~(R | Qbar);
  assign Qbar = ~(S | Q);
endmodule