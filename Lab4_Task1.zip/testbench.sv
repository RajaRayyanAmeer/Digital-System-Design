module rs_latch_tb;

reg S, R;
wire Q, Qbar;

rs_latch s1 (S,R,Q,Qbar);

initial
  begin
    $dumpfile("file.vcd");
    $dumpvars(1);
    S=0; R=0;
    #2S=0; R=1;
    #2S=1; R=0;
    #2S=1; R=1;
    #2
  $finish();
end
endmodule