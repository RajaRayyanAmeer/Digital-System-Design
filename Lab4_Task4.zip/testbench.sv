module reg4_tb;
  reg [3:0]D;
  reg Clk, Rst;
  wire [3:0]Q;
  reg4 r1(.D(D), .Clk(Clk), .Rst(Rst), .Q(Q));
  initial
    begin
      $dumpfile("file.vcd");
      $dumpvars(1, reg4_tb);
    end
  initial
    begin
      Clk = 0;
      forever #1 Clk = ~Clk;
    end
  initial
    begin
      Rst = 1; D = 4'b0000;
      #2 Rst = 0;
      #2 D = 4'b0101;
      #2 D = 4'b0111;
      #2 D = 4'b1101;
      #2 D = 4'b1110;
      Rst = 1;
      #2
      $finish();
    end
endmodule