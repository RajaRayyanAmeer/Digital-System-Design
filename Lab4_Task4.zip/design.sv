module d_flipflop(
  input D, Clk, Rst,
  output reg Q);
  always @ (posedge Clk or posedge Rst)
    begin
      if (Rst)
        Q <= 1'b0;
      else
        Q <= D;
    end
endmodule

module reg4(
  input [3:0] D,
  input Clk, Rst,
  output [3:0] Q);
  d_flipflop d1 (D[0], Clk, Rst, Q[0]);
  d_flipflop d2 (D[1], Clk, Rst, Q[1]);
  d_flipflop d3 (D[2], Clk, Rst, Q[2]);
  d_flipflop d4 (D[3], Clk, Rst, Q[3]);
endmodule