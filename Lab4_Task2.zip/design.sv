module d_latch(
  input D,Clk,
  output reg Q,
  output reg Qbar);
  always @ (D or Clk)
    begin
      if (Clk)
        begin
          Q <= D;
          Qbar <= ~D;
        end
    end
endmodule