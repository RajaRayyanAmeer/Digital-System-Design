module tb_d_latch;
  reg D,Clk;
  wire Q,Qbar;
  d_latch d1(.D(D),.Clk(Clk),.Q(Q),.Qbar(Qbar));
  initial
    begin
      Clk = 0;
      $dumpfile("file.vcd");
      $dumpvars(1,tb_d_latch);
      Clk=0;D=0;
      #2Clk=0;D=1;
      #2Clk=1;D=0;
      #2Clk=1;D=1;
      #2
      $finish();
    end
endmodule